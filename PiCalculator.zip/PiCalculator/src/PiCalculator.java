import java.util.Scanner;

public class PiCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Kullanıcıdan terim sayısını al
        System.out.print("Kaç terimi hesaplamak istersiniz? (1-200): ");
        int terms = scanner.nextInt();
        
        if (terms < 1 || terms > 200) {
            System.out.println("Lütfen 1 ile 200 arasında bir sayı giriniz.");
            scanner.close();
            return;
        }

        double pi = 0.0;

        // Kullanıcının girdiği terim sayısı kadar döngü
        for (int i = 0; i < terms; i++) {
            // Her terimi hesapla
            double term = 4.0 / (2 * i + 1);
            if (i % 2 == 0) {
                pi += term;  // Çift indekslerde terimi ekle
            } else {
                pi -= term;  // Tek indekslerde terimi çıkar
            }

            // Pi'nin her terimini 6 ondalıklı basamağa kadar yazdır
            System.out.printf("%d %.6f\n", i + 1, pi);
        }

        scanner.close();
    }
}
